(function () {
  'use strict';

  var SELECTORS = {
    burger: '.burger',
    nav: '.nav',
    reveal: '.reveal',
    year: '#year',
    reviewsData: '#reviews-tg-data',
    reviewsMount: '#reviews-swap',
    reviewsFallback: '#reviews-fallback',
    worksData: '#works-manifest-data',
    worksGrid: '#works-bounce-row',
    worksStatus: '#works-status',
    worksMore: '#works-more-btn'
  };

  function $(selector, root) {
    return (root || document).querySelector(selector);
  }

  function $all(selector, root) {
    return Array.prototype.slice.call((root || document).querySelectorAll(selector));
  }

  function parseJSONScript(selector) {
    var el = $(selector);
    if (!el || !el.textContent.trim()) return null;
    try {
      return JSON.parse(el.textContent);
    } catch (error) {
      console.warn('Не удалось прочитать JSON:', selector, error);
      return null;
    }
  }

  function safeText(value, fallback) {
    var text = String(value == null ? '' : value).trim();
    return text || fallback || '';
  }

  function setCurrentYear() {
    var node = $(SELECTORS.year);
    if (node) node.textContent = String(new Date().getFullYear());
  }

  function initMenu() {
    var burger = $(SELECTORS.burger);
    var nav = $(SELECTORS.nav);
    if (!burger || !nav) return;

    function setOpen(open) {
      nav.classList.toggle('nav--open', open);
      burger.setAttribute('aria-expanded', open ? 'true' : 'false');
    }

    burger.addEventListener('click', function () {
      setOpen(!nav.classList.contains('nav--open'));
    });

    nav.addEventListener('click', function (event) {
      if (event.target.closest('a')) setOpen(false);
    });

    document.addEventListener('keydown', function (event) {
      if (event.key === 'Escape') setOpen(false);
    });
  }

  function initReveal() {
    var nodes = $all(SELECTORS.reveal);
    if (!nodes.length) return;

    if (!('IntersectionObserver' in window)) {
      nodes.forEach(function (node) { node.classList.add('visible'); });
      return;
    }

    var observer = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (!entry.isIntersecting) return;
        entry.target.classList.add('visible');
        observer.unobserve(entry.target);
      });
    }, { threshold: 0.1, rootMargin: '0px 0px -7% 0px' });

    nodes.forEach(function (node) { observer.observe(node); });
  }

  function initSoftParallax() {
    if (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    $all('.parallax-wrap').forEach(function (wrap) {
      var children = $all('[data-depth-child]', wrap);
      if (!children.length) return;
      var strength = parseFloat(wrap.getAttribute('data-depth')) || 0.06;

      wrap.addEventListener('pointermove', function (event) {
        var rect = wrap.getBoundingClientRect();
        if (!rect.width || !rect.height) return;
        var x = (event.clientX - rect.left) / rect.width - 0.5;
        var y = (event.clientY - rect.top) / rect.height - 0.5;
        children.forEach(function (child, index) {
          var move = (index + 1) * strength * 16;
          child.style.transform = 'translate3d(' + (-x * move).toFixed(2) + 'px,' + (-y * move).toFixed(2) + 'px,0)';
        });
      });

      wrap.addEventListener('pointerleave', function () {
        children.forEach(function (child) { child.style.transform = ''; });
      });
    });
  }

  function starsRow(value) {
    var count = parseInt(value, 10);
    if (!Number.isFinite(count)) count = 5;
    count = Math.max(1, Math.min(5, count));
    return Array.from({ length: 5 }, function (_, index) { return index < count ? '★' : '☆'; }).join('');
  }

  function renderReviews() {
    var mount = $(SELECTORS.reviewsMount);
    var fallback = $(SELECTORS.reviewsFallback);
    if (!mount) return;

    var data = parseJSONScript(SELECTORS.reviewsData);
    var items = data && Array.isArray(data.items) ? data.items : [];
    items = items.filter(function (item) { return item && safeText(item.text); }).slice(0, 6);

    if (!items.length) {
      if (fallback) fallback.hidden = false;
      mount.hidden = true;
      return;
    }

    mount.innerHTML = '';
    items.forEach(function (item) {
      var name = safeText(item.name, 'Гостья');
      var card = document.createElement('article');
      card.className = 'review-card glass-card';

      var top = document.createElement('div');
      top.className = 'review__top';

      var avatar = document.createElement('div');
      avatar.className = 'review__avatar';
      avatar.setAttribute('aria-hidden', 'true');
      avatar.textContent = name.charAt(0).toUpperCase();

      var meta = document.createElement('div');
      var title = document.createElement('p');
      title.className = 'review__name';
      title.textContent = name;
      var stars = document.createElement('p');
      stars.className = 'review__stars';
      stars.textContent = starsRow(item.stars);
      stars.setAttribute('aria-label', safeText(item.stars, 5) + ' из 5');
      meta.appendChild(title);
      meta.appendChild(stars);

      var text = document.createElement('p');
      text.className = 'review__text';
      text.textContent = safeText(item.text);

      top.appendChild(avatar);
      top.appendChild(meta);
      card.appendChild(top);
      card.appendChild(text);

      if (item.post && /t\.me\/[\w_\-]+\/\d+/i.test(String(item.post))) {
        var source = document.createElement('p');
        source.className = 'review__source';
        var link = document.createElement('a');
        link.href = String(item.post).trim();
        link.target = '_blank';
        link.rel = 'noopener noreferrer';
        link.textContent = 'Пост в канале →';
        source.appendChild(link);
        card.appendChild(source);
      }

      mount.appendChild(card);
    });

    mount.hidden = false;
    if (fallback) fallback.hidden = true;
  }

  var lightbox = {
    root: null,
    img: null,
    meta: null,
    counter: null,
    track: null,
    slides: [],
    index: 0,
    open: false
  };

  function ensureLightbox() {
    if (lightbox.root) return;

    var root = document.createElement('div');
    root.id = 'works-carousel';
    root.className = 'works-carousel';
    root.setAttribute('role', 'dialog');
    root.setAttribute('aria-modal', 'true');
    root.setAttribute('aria-hidden', 'true');
    root.setAttribute('aria-label', 'Галерея работ');
    root.innerHTML = [
      '<div class="works-carousel__backdrop" tabindex="-1"></div>',
      '<div class="works-carousel__panel">',
      '<button type="button" class="works-carousel__close" aria-label="Закрыть галерею">×</button>',
      '<button type="button" class="works-carousel__nav works-carousel__nav--prev" aria-label="Предыдущее фото">‹</button>',
      '<button type="button" class="works-carousel__nav works-carousel__nav--next" aria-label="Следующее фото">›</button>',
      '<div class="works-carousel__stage"><img class="works-carousel__img" alt="" decoding="async" draggable="false"/><p class="works-carousel__meta"></p></div>',
      '<div class="works-carousel__foot"><span class="works-carousel__counter"></span><div class="works-carousel__track" role="list" aria-label="Миниатюры"></div></div>',
      '</div>'
    ].join('');

    document.body.appendChild(root);
    lightbox.root = root;
    lightbox.img = $('.works-carousel__img', root);
    lightbox.meta = $('.works-carousel__meta', root);
    lightbox.counter = $('.works-carousel__counter', root);
    lightbox.track = $('.works-carousel__track', root);

    $('.works-carousel__backdrop', root).addEventListener('click', closeLightbox);
    $('.works-carousel__close', root).addEventListener('click', closeLightbox);
    $('.works-carousel__nav--prev', root).addEventListener('click', function () { moveLightbox(-1); });
    $('.works-carousel__nav--next', root).addEventListener('click', function () { moveLightbox(1); });

    var startX = 0;
    var startY = 0;
    $('.works-carousel__stage', root).addEventListener('touchstart', function (event) {
      if (!event.touches || !event.touches[0]) return;
      startX = event.touches[0].clientX;
      startY = event.touches[0].clientY;
    }, { passive: true });

    $('.works-carousel__stage', root).addEventListener('touchend', function (event) {
      if (!event.changedTouches || !event.changedTouches[0]) return;
      var dx = event.changedTouches[0].clientX - startX;
      var dy = event.changedTouches[0].clientY - startY;
      if (Math.abs(dx) > 46 && Math.abs(dx) > Math.abs(dy)) moveLightbox(dx < 0 ? 1 : -1);
    }, { passive: true });
  }

  function renderLightbox() {
    var slide = lightbox.slides[lightbox.index];
    if (!slide || !lightbox.img) return;

    lightbox.img.src = slide.url;
    lightbox.img.alt = slide.title + ' — ' + slide.category;
    lightbox.meta.textContent = slide.category + ' · ' + slide.title;
    lightbox.counter.textContent = (lightbox.index + 1) + ' / ' + lightbox.slides.length;
    lightbox.track.innerHTML = '';

    lightbox.slides.forEach(function (item, index) {
      var thumb = document.createElement('button');
      thumb.type = 'button';
      thumb.className = 'works-carousel__thumb' + (index === lightbox.index ? ' works-carousel__thumb--active' : '');
      thumb.setAttribute('aria-label', 'Фото ' + (index + 1));
      var img = document.createElement('img');
      img.src = item.url;
      img.alt = '';
      img.loading = 'lazy';
      img.draggable = false;
      thumb.appendChild(img);
      thumb.addEventListener('click', function () {
        lightbox.index = index;
        renderLightbox();
      });
      lightbox.track.appendChild(thumb);
    });

    var active = lightbox.track.children[lightbox.index];
    if (active && active.scrollIntoView) active.scrollIntoView({ block: 'nearest', inline: 'center', behavior: 'smooth' });
  }

  function openLightbox(slides, index) {
    ensureLightbox();
    lightbox.slides = slides;
    lightbox.index = Math.max(0, Math.min(index || 0, slides.length - 1));
    lightbox.open = true;
    lightbox.root.classList.add('works-carousel--open');
    lightbox.root.setAttribute('aria-hidden', 'false');
    document.body.classList.add('works-carousel-lock');
    document.addEventListener('keydown', lightboxKeys);
    renderLightbox();
    var close = $('.works-carousel__close', lightbox.root);
    if (close) close.focus();
  }

  function closeLightbox() {
    if (!lightbox.root) return;
    lightbox.open = false;
    lightbox.root.classList.remove('works-carousel--open');
    lightbox.root.setAttribute('aria-hidden', 'true');
    document.body.classList.remove('works-carousel-lock');
    document.removeEventListener('keydown', lightboxKeys);
  }

  function moveLightbox(delta) {
    if (!lightbox.slides.length) return;
    lightbox.index = (lightbox.index + delta + lightbox.slides.length) % lightbox.slides.length;
    renderLightbox();
  }

  function lightboxKeys(event) {
    if (!lightbox.open) return;
    if (event.key === 'Escape') {
      event.preventDefault();
      closeLightbox();
    } else if (event.key === 'ArrowLeft') {
      event.preventDefault();
      moveLightbox(-1);
    } else if (event.key === 'ArrowRight') {
      event.preventDefault();
      moveLightbox(1);
    }
  }

  function flattenWorks(data) {
    if (!data || !Array.isArray(data.categories)) return [];
    return data.categories.reduce(function (acc, category) {
      var title = safeText(category.title, 'Работа');
      var images = Array.isArray(category.images) ? category.images : [];
      images.forEach(function (url, index) {
        if (!safeText(url)) return;
        acc.push({
          url: String(url),
          category: title,
          title: title + ' #' + (index + 1)
        });
      });
      return acc;
    }, []);
  }

  function loadWorksManifest() {
    var embedded = parseJSONScript(SELECTORS.worksData);
    if (embedded && Array.isArray(embedded.categories)) return Promise.resolve(embedded);

    return fetch('works-manifest.json', { cache: 'no-store' })
      .then(function (response) {
        if (!response.ok) throw new Error('manifest');
        return response.json();
      })
      .catch(function () { return embedded || null; });
  }

  function initWorks() {
    var grid = $(SELECTORS.worksGrid);
    var status = $(SELECTORS.worksStatus);
    var more = $(SELECTORS.worksMore);
    if (!grid) return;

    var shown = 0;
    var step = 9;
    var slides = [];

    function renderMore() {
      var next = slides.slice(shown, shown + step);
      next.forEach(function (slide, localIndex) {
        var index = shown + localIndex;
        var card = document.createElement('button');
        card.type = 'button';
        card.className = 'work-card';
        card.setAttribute('aria-label', 'Открыть фото: ' + slide.category);

        var img = document.createElement('img');
        img.src = slide.url;
        img.alt = slide.category;
        img.loading = index < 3 ? 'eager' : 'lazy';
        img.decoding = 'async';
        img.draggable = false;

        var meta = document.createElement('span');
        meta.className = 'work-card__meta';
        var category = document.createElement('span');
        category.className = 'work-card__category';
        category.textContent = slide.category;
        var title = document.createElement('span');
        title.className = 'work-card__title';
        title.textContent = 'Открыть просмотр';
        meta.appendChild(category);
        meta.appendChild(title);

        card.appendChild(img);
        card.appendChild(meta);
        card.addEventListener('click', function () { openLightbox(slides, index); });
        grid.appendChild(card);
      });

      shown += next.length;
      if (more) {
        more.disabled = shown >= slides.length;
        more.hidden = shown >= slides.length;
      }
    }

    loadWorksManifest().then(function (data) {
      slides = flattenWorks(data);
      if (!slides.length) {
        if (status) status.textContent = 'Галерея пока не подключена.';
        if (more) more.hidden = true;
        return;
      }

      grid.innerHTML = '';
      if (status) status.textContent = 'Загружено фото: ' + slides.length;
      if (more) {
        more.disabled = false;
        more.hidden = false;
        more.addEventListener('click', renderMore);
      }
      renderMore();
    });
  }

  function protectImages() {
    document.addEventListener('contextmenu', function (event) {
      if (event.target && event.target.tagName === 'IMG' && event.target.closest('#works-bounce-row, #works-carousel, .hero__visual')) {
        event.preventDefault();
      }
    }, true);

    document.addEventListener('dragstart', function (event) {
      if (event.target && event.target.tagName === 'IMG' && event.target.closest('#works-bounce-row, #works-carousel, .hero__visual')) {
        event.preventDefault();
      }
    }, true);
  }

  function boot() {
    setCurrentYear();
    initMenu();
    initReveal();
    initSoftParallax();
    renderReviews();
    initWorks();
    protectImages();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})();
