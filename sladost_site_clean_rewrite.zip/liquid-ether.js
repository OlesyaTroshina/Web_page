/* Безопасная заглушка старого жидкого фона. Тяжёлый WebGL-фон отключён, чтобы не перекрывать сайт. */
window.initLiquidEther = window.initLiquidEther || function () {
  return function cleanupLiquidEther() {};
};
