/* Безопасная заглушка старого модуля эффектов: сайт больше не зависит от GSAP/WebGL. */
window.SladostEffects = window.SladostEffects || {
  initBorderGlow: function () {},
  initCardSwap: function () {},
  initBounceCards: function () {},
  initClickSpark: function () {},
  initWorksBounce: function () {},
  initAll: function () {}
};
